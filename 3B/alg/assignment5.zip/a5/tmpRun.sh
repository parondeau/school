python maxSAT.py 8 2 20 10
