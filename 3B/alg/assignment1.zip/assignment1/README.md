Assignment 1:

In order to run, execute run script in this folder

./run.sh

Files assignment1.py and greedy.py are the two algorithms
Included are various commented debugging and testing functions used during development to test correctness
