#!/usr/bin/env python
# coding=utf-8

print "test"
import assignment1

# assignment1
print "Foo"